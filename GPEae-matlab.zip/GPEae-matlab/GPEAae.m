function [bestFitness,bestFitness_gobal,bestSolution_gobal]=GPEAae(fhd,D,Pop_Number,Max_gen,VRmin,VRmax,func_num,th)
global initial_flag
initial_flag=0;  
% GPEA: Grey prediction evolution algorithm for global optimization
% Brief description: GPEA is a new optimization technique, the core of GPEA is considering the population series of evolutionary algorithms as a time series, and uses the even grey model as a reproduction operator to forecast the next population (without employing anymutation and crossover operators).
% Dimension: D --- dimension of solution space
%% Input:
%                             Dimension                   Description
%      D                      1 x 1                       dimension of solution space
%      Pop_Number             1 x 1                       population size
%      Max_Gen                1 x 1                       maximum  generations
%      VRmin                  1 x D                       low bound of variable in test function
%      VRmax                  1 x D                       up bound of variable in test function
%      func_num               1 x l                       the number of test function
%      th                     1 x 1                       difference threshold
%% Output:
%                             Dimension                   Description
%      bestFitness            1 x  Max_Gen                fitness values of the best individuals in each generation
%      bestFitness_gobal      1 x  1                      the fitness value of the gobal best individual
%      bestSolution_gobal     1 x  1                      the gobal best individual
%%  Reference and Contact
% Reference: [1]Cong Gao, Zhongbo Hu, Zenggang Xiong, Qinghua Su. Grey prediction evolution algorithm based on accelerated even grey model.  IEEE Access, 2020.
%            [2]Zhongbo Hu, Xinlin Xu, and Qinghua Su et al., Grey prediction evolution algorithm for global optimization, Applied Mathematical Modelling, 2020, 79, 145�C160.https://doi.org/10.1016/j.apm.2019.10.026
%            [3]Xinlin Xu, Zhongbo Hu, Qinghua Su, Yuanxiang Li, Juanhua Dai. Multivariable grey prediction evolution algorithm: A new metaheuristic, Applied Soft Computing, 2020, 89, 106086. https://doi.org/10.1016/j.asoc.2020.106086
%            [4]Canyun Dai, Zhongbo Hu, Zheng Li, Zenggang Xiong, Qinghua Su. An improved grey prediction evolution algorithm based on Topological Opposition-based learning. IEEE Access, vol. 8, pp. 30745-30762, 2020.https://doi.org/10.1109/ACCESS.2020.2973197
% Contact: For any questions, please feel free to send email to huzbdd@126.com.

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% The initialization operator of GPEA. 
%The initialization process of GPEA has to initialize three generation populations,it can be divided into two parts:
%The first part is to initialize the first generation with random uniform distribution;
%The second part is to generate the second and third generation population using DE.
% Note: The data sequences used by GPEA are all non-negative datasets.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Initialize parameters
F=0.7;                    %Scaling factor or mutation factor,the value range is��0,1.2]
CR=0.7;                   %Crossover factor
%% Initialize the first generation population
Vrmin=ones(1,D)*(VRmin+abs(VRmin));                           %Initialize low bound of variable 
Vrmax=ones(1,D)*(VRmax+abs(VRmin));                           %Initialize up bound of variable
Pop=repmat(Vrmin,Pop_Number,1)+(repmat(Vrmax,Pop_Number,1)-repmat(Vrmin,Pop_Number,1)).*rand(Pop_Number,D);   %Initialize the first generation population 
originPop(1)={Pop};                                           %Store the first generation population
%% Evaluate the population
Fitness_Pop=feval(fhd,Pop'-abs(VRmin),func_num);          %Calculate the function values of the first generation population 
[bestFitness(1),~]=min(Fitness_Pop);                          %Store the fitness value of the first generation population  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for I=2:3               
%% Mutation operator
%The non-equal three individuals randomly selected from the population to generate a mutation individual
    for i=1:Pop_Number
        Pop_list=randperm(Pop_Number);                                 
        Pop_list(find(Pop_list==i))=[];                             
        Mutant(i,:)=Pop(Pop_list(1),:)+F*(Pop(Pop_list(2),:)-Pop(Pop_list(3),:));     
    end                               
    for i=1:Pop_Number
        for j=1:D
            if Mutant(i,j)<Vrmin(j)||Mutant(i,j)>Vrmax(j)        %Make sure that individuals are in the setting bounds.
                 Mutant(i,j)=Vrmin(j)+(Vrmax(j)-Vrmin(j))*rand;
            end
        end
    end
%% Crossover operator
%Intersect the target individual and its corresponding mutation individual to generate trial individual of the target individual.
    for i=1:Pop_Number
        for j=1:D
            r=randperm(D);
            if rand<=CR||j==r(1)
                 trialPop(i,j)=Mutant(i,j);                     
            else
                 trialPop(i,j)=Pop(i,j);
            end
        end
    end
%% Selection operator
%Compare the value of the target individuals and trial individuals for population evaluation. Individuals with better fitness value will be selected to enter the next iteration
 Fitness_trial=feval(fhd,trialPop'-abs(VRmin),func_num);  %Evaluate the trial population
    for i=1:Pop_Number                                         
        if Fitness_trial(i)<Fitness_Pop(i)      
           Pop(i,:)=trialPop(i,:);
           Fitness_Pop(i)=Fitness_trial(i);
        end
    end
     originPop(I)={Pop};                              %Store the second, third generation population
    [bestFitness(I),~]=min(Fitness_Pop);              %Store the fitness value of the best individual in each generation population
end    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% After a population initialization, the GPEA realizes the function-optimized process by looping a reproduction operator and a selection operator for updating the population.
%% The reproduction operator of GPEA.
%The reproduction operator considers the population series of evolutionary algorithms as a time series. Three successive generations of the population series are regarded as a time series of the even grey model to construct an exponential function for forecasting the next population.
%Three individuals are randomly selected from three generation populations, respectively.
%If all three values of the data series are equal, use a random perturbation strategy to forecast trial individuals;
%If any two values of the data series are equal, use linear fitting model to forecast trial individuals;
%Otherwise, the even grey model is used to forecast trial individuals;
%% The selector operator of GPEA.
%A greedy selection operator is employed to maintain the most promising trial individuals in the next generation.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for I=4:Max_gen
    t=0.01-(3.99/Max_gen)*(I-Max_gen);         %The initial disturbance coefficient
    Pop_list1=randperm(Pop_Number);
    Pop_list2=randperm(Pop_Number);
    Pop_list3=randperm(Pop_Number);
%% The reproduction operator of GPEA.
    for k=1:Pop_Number 
        for j=1:D
            X0=[originPop{1,1}(Pop_list1(k),j),originPop{1,2}(Pop_list2(k),j),originPop{1,3}(Pop_list3(k),j)]; 
            if abs(max(X0)-min(X0))<th                                                    
                trialPop(k,j)=X0(3)+t*2*abs(max(X0)-min(X0))*(rand-0.5);                %Random perturbation model
            elseif abs(X0(1)-X0(2))<th||abs(X0(1)-X0(3))<th||abs(X0(2)-X0(3))<th          
                trialPop(k,j)=(4*X0(3)+X0(2)-2*X0(1))/3;                                %Linear fitting model 
            else                                                                         
                a=2*(X0(2)-X0(3))/(X0(2)+X0(3));                                        %The grey developmental coefficient  
                b=2*(X0(1)*X0(2)+X0(2)^2-X0(1)*X0(3))/(X0(2)+X0(3));                    %The grey control parameter                        
                trialPop(k,j)=(X0(1)-b/a)/exp(3*a)+b/a -X0(3)-X0(2)-X0(1);                  %The accelerated even grey model
            end 
           %% Make sure that individuals are in the setting bounds.
            %If a newly generated individual exceeds the feasible region, the exceeding elements of the new individual are replaced by random numbers in the feasible region.
            if func_num~=25
                if  trialPop(k,j)<Vrmin(j)||trialPop(k,j)>Vrmax(j)
                    trialPop(k,j)=Vrmin(j)+(Vrmax(j)-Vrmin(j))*rand;
                end
            end
        end
    end  
%% The selector operator of GPEA.
 Fitness_trial=feval(fhd,trialPop'-abs(VRmin),func_num);     %Evaluate the trial population
    Pop=originPop{1,3};                              
    for i=1:Pop_Number
        if Fitness_trial(i)<Fitness_Pop(i)
           Pop(i,:)=trialPop(i,:);
           Fitness_Pop(i)=Fitness_trial(i);
        end
    end
     originPop(1,4)={Pop};                          %Generate the true population
     originPop=originPop(2:4);                      %Update the population chain to produce offspring
     [bestFitness(I),~]=min(Fitness_Pop);           %Store the fitness value of the best individual in each generation population
end  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Output bestFitness_gobal and bestSolution_gobal
[bestFitness_gobal,best_index]=min(Fitness_Pop);     %The fitness value of the gobal best individual 
bestSolution_gobal=Pop(best_index,:);                %The gobal best individual                                
end