function plotfig(elitism)
D=6;
plot(elitism(:,D+1),elitism(:,D+2),'k.','MarkerSize',16);
hold on
xlabel('Cost ($/h)','FontSize',13);
ylabel('Emission (ton/h)','FontSize',13);
set(gca,'FontSize',13)
hold off;
end
