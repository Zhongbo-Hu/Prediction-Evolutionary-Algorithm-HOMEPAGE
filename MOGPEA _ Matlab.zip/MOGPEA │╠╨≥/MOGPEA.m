function [sp,hv,elitism]=MOGPEA(M,N)
% Title of article: Multiobjective grey prediction evolution algorithm for environmental/economic dispatch problem

%% Input:
%                             Dimension                      Description
%      Max_Gen=M                1 x 1                     maximum  generations
%      Pop_Number=N             1 x 1                     Population size

%% Output:
%                             Dimension                   Description
%      sp                      1 x  1               spacing (SP): multiobjective performance metrics
%      hv                      1 x  1               hypervolume (HV): multiobjective performance metrics
%      elitism                 1 x  D+2             nondominated solutions of archive

%% Initialize parameters
Ne=50;   % Maximum  capacity of external
D=6;     % Dimensions of solution space
global Case
lx=[0.05 0.05 0.05 0.05 0.05 0.05]; %Low bound of variable
ux=[0.5 0.6 1 1.2 1 0.6]; %Up bound of variable
F=0.5;%Scaling factor or mutation factor,the value range is��0,1.2]
CR=0.5;%Crossover factor
%% Initialize the first generation population
X=repmat(lx,N,1)+(repmat(ux,N,1)-repmat(lx,N,1)).*rand(N,D);
% handling_constraint
X=handle_cons1(X,lx,ux);
originX(1)={X};
% Store individual information
Stem=[];
Cost=func(X); %Calculate the function values
nF=size(Cost,2); % Number of objective functions
Stem(:,1:D)=X;             %Store individual
Stem(:,D+1:D+nF)=Cost;     %Store function values
Stem(:,D+nF+1)=0;      %Store crowding distance
Fx=Cost;

f1min=min(Fx,[],1);
f1max=max(Fx,[],1);
err=0.000001.*(f1max-f1min);
%% Non-dominated solution into the elite set
elitism=[];
flag=zeros(1,N);
for i=1:N-1
    for j=i+1:N
        if (all(Stem(i,D+1:D+nF)<=Stem(j,D+1:D+nF)) && any(Stem(i,D+1:D+nF)<Stem(j,D+1:D+nF)))||((Stem(i,D+1)-Stem(j,D+1)<err(1))&&(abs(Stem(i,D+2)-Stem(j,D+2))<err(2)))
            flag(j)=1;
        end
        if all(Stem(j,D+1:D+nF)<=Stem(i,D+1:D+nF)) && any(Stem(j,D+1:D+nF)<Stem(i,D+1:D+nF))
            flag(i)=1;
        end
    end
end
elitism=Stem(find(flag==0),:);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for I=2:3
    %% Mutation operator (DE/rand/1)
    for i=1:N
        dx=randperm(N);   %�������1��Np֮�����ظ�������
        dx(find(dx==i))=[];
        Meta(i,:)=X(dx(1),:)+F*(X(dx(2),:)-X(dx(3),:));   %���ɱ���ʸ��Xm
    end
    % boundary treatment
    for i=1:N
        for j=1:D
            if Meta(i,j)<lx(j)||Meta(i,j)>ux(j)
                Meta(i,j)=lx(j)+(ux(j)-lx(j))*rand;
            end
        end
    end
    %% Crossover operator
    for i=1:N
        for j=1:D
            r=randperm(N);
            if rand<=CR|j==r(1)
                T(i,j)=Meta(i,j);
            else
                T(i,j)=X(i,j);
            end
        end
    end
    % handling_constraint
    T=handle_cons1(T,lx,ux);
    %Calculate the function values
    Fnewpop=func(T);
    
    %% Selection operator
    for i=1:N
        dist=sum((X-repmat(T(i,:),N,1)).^2,2);
        [~,near_idx]=min(dist);
        f1=Fx(near_idx,:)-Fnewpop(i,:)<=0;
        f2=Fx(near_idx,:)-Fnewpop(i,:)<0;
        f3=Fx(near_idx,:)-Fnewpop(i,:)<err;
        
        f4=Fnewpop(i,:)-Fx(near_idx,:)<=0;
        f5=Fnewpop(i,:)-Fx(near_idx,:) <0;
        f6=Fnewpop(i,:)-Fx(near_idx,:) <err;
        if ((sum(f1)==nF)&&(sum(f2)>0))||((sum(f3)==nF)&&(sum(f6)<nF)) %parent dominates child
        elseif ((sum(f4)==nF)&&(sum(f5)>0))||((sum(f6)==nF)&&(sum(f3)<nF))% child dominates parent
            X(near_idx,:)=T(i,:);
            Fx(near_idx,:)=Fnewpop(i,:);
        else
            a1=rand; b1=rand;%Generate two random numbers
            if a1<b1
                X(near_idx,:)=T(i,:);
                Fx(near_idx,:)=Fnewpop(i,:);
            end
        end
    end
    
    f1min=min(Fx,[],1);
    f1max=max(Fx,[],1);
    err=0.00001.*(f1max-f1min);
    
    Stem=[];
    Stem(:,1:D)=X;        % Store individual
    Stem(:,D+1:D+nF)=Fx;  %Store function values
    Stem(:,D+nF+1)=0;    %Store crowding distance
    
    %% Non-dominated solution into the elite set
    elitism1=[];
    flag=zeros(1,N);
    for i=1:N-1
        for j=i+1:N
            if (all(Stem(i,D+1:D+nF)<=Stem(j,D+1:D+nF)) && any(Stem(i,D+1:D+nF)<Stem(j,D+1:D+nF)))||((abs(Stem(i,D+1)-Stem(j,D+1))<err(1))&&(abs(Stem(i,D+2)-Stem(j,D+2))<err(2)))
                flag(j)=1;
            end
            if all(Stem(j,D+1:D+nF)<=Stem(i,D+1:D+nF)) && any(Stem(j,D+1:D+nF)<Stem(i,D+1:D+nF))
                flag(i)=1;
            end
        end
    end
    elitism1=Stem(find(flag==0),:);
    elitism=[elitism;elitism1];
    
    % Delete dominated solution to form a new elite set
    flag=zeros(1,size(elitism,1));
    for i=1:size(elitism,1)-1
        for j=i+1:size(elitism,1)
            if (all(elitism(i,D+1:D+nF)<=elitism(j,D+1:D+nF)) && any(elitism(i,D+1:D+nF)<elitism(j,D+1:D+nF)))||((abs(elitism(i,D+1)-elitism(j,D+1))<err(1))&&(abs(elitism(i,D+2)-elitism(j,D+2))<err(2)))
                flag(j)=1;
            end
            if all(elitism(j,D+1:D+nF)<=elitism(i,D+1:D+nF)) && any(elitism(j,D+1:D+nF)<elitism(i,D+1:D+nF))
                flag(i)=1;
            end
        end
    end
    elitism(find(flag==1),:)=[];
    
    % External archive maintenance strategy
    while size(elitism,1)>Ne
        elitism(:,D+nF+1)=0;
        for f=1:nF
            elitism=sortrows(elitism,D+f);
            elitism(1,D+nF+1)=inf;
            fmax=max(elitism(:,D+f));  % Find the maximum objective function values
            fmin=min(elitism(:,D+f));  % Find the minimum objective function values
            
            % Calculate crowding distance of the elitism set
            for i=2:(size(elitism,1)-1)
                elitism(i,D+nF+1)=elitism(i,D+nF+1)+abs((elitism(i+1,D+f)-elitism(i-1,D+f))/(elitism(1,D+f)-elitism(end,D+f)));%*exp(-abs(elitism(i+1,D+f)+elitism(i-1,D+f)-2*elitism(i,D+f)));
            end
            elitism(end,D+nF+1)=inf;
        end
        elitism=sortrows(elitism,-(D+nF+1));  % Sort by the crowding distance from large to small
        elitism(end,:)=[];  %Delete the last
    end
    
    originX(I)={X};
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
aa1=0;bb1=0;
for I=4:M
    %% Leader-updating strategy
    SP=[];% Calculate of maximum distance
    sd=[];% Calculate sparse direction
    ne=size(elitism,1);
    elitism=sortrows(elitism,D+1);
    sd(1)=1;
    sd(ne)=-1;
    SP(1)=5*abs((elitism(1,D+1)-elitism(2,D+1))/(elitism(1,D+1)-elitism(ne,D+1)))+abs((elitism(1,D+2)-elitism(2,D+2))/(elitism(1,D+2)-elitism(ne,D+2)));
    SP(ne)=5*abs((elitism(ne-1,D+1)-elitism(ne,D+1))/(elitism(1,D+1)-elitism(ne,D+1)))+abs((elitism(ne-1,D+2)-elitism(ne,D+2))/(elitism(1,D+2)-elitism(ne,D+2)));
    for i=2:ne-1
        sp1=abs((elitism(i,D+1)-elitism(i-1,D+1))/(elitism(1,D+1)-elitism(ne,D+1)))+abs((elitism(i,D+2)-elitism(i-1,D+2))/(elitism(1,D+2)-elitism(ne,D+2)));
        sp2=abs((elitism(i,D+1)-elitism(i+1,D+1))/(elitism(1,D+1)-elitism(ne,D+1)))+abs((elitism(i,D+2)-elitism(i+1,D+2))/(elitism(1,D+2)-elitism(ne,D+2)));
        [SP(i),d]=max([sp1,sp2]);
        sd(i)=2*(d-1.5);
    end
    e=SP/sum(SP);
    ec=cumsum(e);
    
    t=((1-4)/M)*I+4;
    th=(ux-lx)/t; %Difference threshold
    aa=randperm(N);
    bb=randperm(N);
    cc=randperm(N);
    for ii=1:N
        % Roulette wheel selection mechanism to select the leader of the archive
        dx1=[];
        dx1=find(ec>=rand);
        L=elitism(dx1(1),1:D);
        for jj=1:D
            X0=[];X1=[];Z1=[];Y=[];a=[];b=[];A=[];B=[];
            X0=[originX{1,1}(aa(ii),jj),originX{1,2}(bb(ii),jj),originX{1,3}(cc(ii),jj)];
            %% The reproduction operator of GPEA.
            if abs(max(X0)-min(X0))>th(jj)
                aa1=aa1+1;
                X1(1)=X0(1);
                for i=2:3
                    X1(i)=X1(i-1)+X0(i); %Accumulative sequence
                end
                Z1=[];
                for i=1:2
                    Z1(i)=(X1(i)+X1(i+1))/2;    % Mean sequence
                end
                XX=X0;
                XX(1)=[];
                Y=XX';
                
                B(:,1)=-Z1';
                B(:,2)=1;
                A=inv(B'*B)*B'*Y;
                a=A(1,1);    % Calculate grey developmental coefficient a
                if a==0
                    % Leader-guiding strategy
                    if dx1(1)==1||dx1(1)==ne
                        T(ii,jj)=L(1,jj)+(-1)*rand*(elitism(dx1(1)+sd(dx1(1)),jj)-L(1,jj));
                    else
                        T(ii,jj)=L(1,jj)+rand*(elitism(dx1(1)+sd(dx1(1)),jj)-L(1,jj));
                    end
                else
                    b=A(2,1); %Calculate  gray control parameter b
                    %EGM(1,1) prediction
                    F=[];
                    for i=1:4
                        F(i)=(X0(1)-b/a)/exp(a*(i-1))+b/a;
                    end
                    G=[];
                    G(1)=X0(1);
                    for i=2:4
                        G(i)=F(i)-F(i-1);
                    end
                    T(ii,jj)=G(4);
                end
            else
                % Leader-guiding strategy
                bb1=bb1+1;
                if dx1(1)==1||dx1(1)==ne
                    T(ii,jj)=L(1,jj)+(-1)*rand*(elitism(dx1(1)+sd(dx1(1)),jj)-L(1,jj));
                else
                    T(ii,jj)=L(1,jj)+rand*(elitism(dx1(1)+sd(dx1(1)),jj)-L(1,jj));
                end
            end
            % boundary treatment
            if  T(ii,jj)<lx(jj)||T(ii,jj)>ux(jj)
                T(ii,jj)=lx(jj)+(ux(jj)-lx(jj))*rand;
            end
        end
    end
    % handling_constraint
    T=handle_cons1(T,lx,ux);
    %Calculate the function values
    Fnewpop=func(T);
    
    %% Selection operator
    for i=1:N
        dist=sum((X-repmat(T(i,:),N,1)).^2,2);
        [junk,near_idx]=min(dist);
        f1=Fx(near_idx,:)-Fnewpop(i,:)<=0;
        f2=Fx(near_idx,:)-Fnewpop(i,:)<0;
        f3=Fx(near_idx,:)-Fnewpop(i,:)<err;
        
        f4=Fnewpop(i,:)-Fx(near_idx,:)<=0;
        f5=Fnewpop(i,:)-Fx(near_idx,:) <0;
        f6=Fnewpop(i,:)-Fx(near_idx,:) <err;
        if ((sum(f1)==nF)&&(sum(f2)>0))||((sum(f3)==nF)&&(sum(f6)<nF)) %parent dominates child
        elseif ((sum(f4)==nF)&&(sum(f5)>0))||((sum(f6)==nF)&&(sum(f3)<nF))% child dominates parent
            X(near_idx,:)=T(i,:);
            Fx(near_idx,:)=Fnewpop(i,:);
        else
            a1=rand; b1=rand;
            if a1<b1
                X(near_idx,:)=T(i,:);
                Fx(near_idx,:)=Fnewpop(i,:);
            end
        end
    end
    
    f1min=min(Fx,[],1);
    f1max=max(Fx,[],1);
    err=0.00001.*(f1max-f1min);
    
    Stem=[];
    Stem(:,1:D)=X;              % Store individual
    Stem(:,D+1:D+nF)=Fx;      %Store function values
    Stem(:,D+nF+1)=0;            %Store crowding distance
    
    %% Non-dominated solution into the elite set
    elitism1=[];
    flag=zeros(1,N);
    for i=1:N-1
        for j=i+1:N
            if (all(Stem(i,D+1:D+nF)<=Stem(j,D+1:D+nF)) && any(Stem(i,D+1:D+nF)<Stem(j,D+1:D+nF)))||((abs(Stem(i,D+1)-Stem(j,D+1))<err(1))&&(abs(Stem(i,D+2)-Stem(j,D+2))<err(2)))
                flag(j)=1;
            end
            if all(Stem(j,D+1:D+nF)<=Stem(i,D+1:D+nF)) && any(Stem(j,D+1:D+nF)<Stem(i,D+1:D+nF))
                flag(i)=1;
            end
        end
    end
    elitism1=Stem(find(flag==0),:);
    elitism=[elitism;elitism1];
    
    % Delete dominated solution to form a new elite set
    flag=zeros(1,size(elitism,1));
    for i=1:size(elitism,1)-1
        for j=i+1:size(elitism,1)
            if (all(elitism(i,D+1:D+nF)<=elitism(j,D+1:D+nF)) && any(elitism(i,D+1:D+nF)<elitism(j,D+1:D+nF)))||((abs(elitism(i,D+1)-elitism(j,D+1))<err(1))&&(abs(elitism(i,D+2)-elitism(j,D+2))<err(2)))
                flag(j)=1;
            end
            if all(elitism(j,D+1:D+nF)<=elitism(i,D+1:D+nF)) && any(elitism(j,D+1:D+nF)<elitism(i,D+1:D+nF))
                flag(i)=1;
            end
        end
    end
    elitism(find(flag==1),:)=[];
    
    % External archive maintenance strategy
    while size(elitism,1)>Ne
        elitism(:,D+nF+1)=0;
        for f=1:nF
            elitism=sortrows(elitism,D+f);
            elitism(1,D+nF+1)=inf;
            fmax=max(elitism(:,D+f));  % Find the maximum objective function values
            fmin=min(elitism(:,D+f));  % Find the minimum objective function values
            
            % Calculate crowding distance of the elitism set
            for i=2:(size(elitism,1)-1)
                elitism(i,D+nF+1)=elitism(i,D+nF+1)+abs((elitism(i+1,D+f)-elitism(i-1,D+f))/(elitism(1,D+f)-elitism(end,D+f)));%*exp(-abs(elitism(i+1,D+f)+elitism(i-1,D+f)-2*elitism(i,D+f)));
            end
            elitism(end,D+nF+1)=inf;
        end
        elitism=sortrows(elitism,-(D+nF+1));  % Sort by the crowding distance from large to small
        elitism(end,:)=[]; %Delete the last
    end
    
    originX(1,4)={X};
    originX=originX(2:4);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Calculate SP performance metrics
elitism=sortrows(elitism,D+1);
SP(1)=abs((elitism(1,D+1)-elitism(2,D+1))/(elitism(1,D+1)-elitism(end,D+1)))+abs((elitism(1,D+2)-elitism(2,D+2))/(elitism(1,D+2)-elitism(end,D+2)));
SP(size(elitism,1))=abs((elitism(end-1,D+1)-elitism(end,D+1))/(elitism(1,D+1)-elitism(end,D+1)))+abs((elitism(end-1,D+2)-elitism(end,D+2))/(elitism(1,D+2)-elitism(end,D+2)));
for i=2:size(elitism,1)-1
    sp1=abs((elitism(i,D+1)-elitism(i-1,D+1))/(elitism(1,D+1)-elitism(end,D+1)))+abs((elitism(i,D+2)-elitism(i-1,D+2))/(elitism(1,D+2)-elitism(end,D+2)));
    sp2=abs((elitism(i,D+1)-elitism(i+1,D+1))/(elitism(1,D+1)-elitism(end,D+1)))+abs((elitism(i,D+2)-elitism(i+1,D+2))/(elitism(1,D+2)-elitism(end,D+2)));
    SP(i)=min([sp1,sp2]);
end
sp=sqrt(sum((SP-mean(SP)).^2)/(size(elitism,1)-1));
%% Calculate HV performance metrics
HV=[];
w1=650;
w2=0.225;
HV(1)=abs((w1-elitism(1,D+1))*(w2-elitism(1,D+2)));
for i=2:size(elitism,1)
    HV(i)=abs((w1-elitism(i,D+1))*(elitism(i-1,D+2)-elitism(i,D+2)));
end
hv=sum(HV);
end