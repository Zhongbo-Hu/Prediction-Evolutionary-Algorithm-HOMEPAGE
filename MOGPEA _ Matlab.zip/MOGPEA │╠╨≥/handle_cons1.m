function x=handle_cons1(x,pmin,pmax) 
global Case
Pd=2.834;
[N,D]=size(x);
for i=1:N
    Dif=Pd+Pless(x(i,:))-sum(x(i,:));
    k=round(rand(1,1)*(D-1))+1;
    while abs(Dif)>1E-10
        x(i,k)=x(i,k)*(Pd+Pless(x(i,:)))/sum(x(i,:));
        if x(i,k)<pmin(k)
            x(i,k)=pmin(k);
        elseif x(i,k)>pmax(k)
            x(i,k)=pmax(k);
        end
        Dif=Pd+Pless(x(i,:))-sum(x(i,:));
        k=mod(k,D)+1;
    end
end
end

function PL=Pless(x)
global Case
if Case==1  % Without transmission loss
    PL=0;
elseif Case==2   % With transmission loss
    B=[0.1382 -0.0299 0.0044 -0.0022 -0.0010 -0.0008;
        -0.0299 0.0487 -0.0025 0.0004 0.0016 0.0041;
        0.0044 -0.0025 0.0182 -0.0070 -0.0066 -0.0066;
        -0.0022 0.0004 -0.0070 0.0137 0.0050 0.0033;
        -0.0010 0.0016 -0.0066 0.0050 0.0109 0.0005;
        -0.0008 0.0041 -0.0066 0.0033 0.0005 0.0244];
    B0=[-0.0107 0.0060 -0.0017 0.0009 0.0002 0.0030];
    B00=0.00098573;
    PL=x*B*x'+sum(B0.*x)+B00;
end
end