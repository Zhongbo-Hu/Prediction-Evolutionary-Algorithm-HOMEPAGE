%% Clear environment
clc;
clear;
close all;
Pop_Number=50;  %Population size      
Max_Gen=200;    %Maximum  generations
global Case
Case=2;   %Case1: without transmission loss  Case2: with transmission loss  
runtimes=30;  %Number of independent cycles

for i=1:runtimes
    i;
    [sp,hv,elitism]=MOGPEA(Max_Gen,Pop_Number);
    SP(i)=sp;HV(i)=hv;AR(i)={elitism};
    bestC(i)=elitism(1,7);
    bestE(i)=elitism(end,8);
    figure(i)
    plotfig(elitism)
end
[~,indx11]=min(bestC);
bestCost=AR{1,indx11}(1,1:8);

[~,indx12]=min(bestE);
bestEmission=AR{1,indx12}(end,1:8);




