%% ��ջ���
clc;
clear;
close all;
Dxh=50;   %����ѭ������
boundary=[-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100];
Lx=boundary(:,1);
Ux=boundary(:,2);
D=10;
N=50;
M=2000;
fhd=str2func('cec14_func');
rand('state',sum(100*clock));

for func_num=1:30
    disp(['��ʼ������Լ����������Ϊ��',num2str(func_num)]);
    Y1=[];Y2=[];Y3=[];Y4=[];Y5=[];Y6=[];
    for dd=1:Dxh
        [y1,best1,bestx1]=TOGPEAe(fhd,D,N,M,Lx(func_num),Ux(func_num),func_num);
        [y2,best2,bestx2]=GPA(fhd,D,N,M,Lx(func_num),Ux(func_num),func_num);
        [y3,best3,bestx3]=aGPAu(fhd,D,N,M,Lx(func_num),Ux(func_num),func_num);
        [y4,best4,bestx4]=aGPAn(fhd,D,N,M,Lx(func_num),Ux(func_num),func_num);
        [y5,best5,bestx5]=aGPAa(fhd,D,N,M,Lx(func_num),Ux(func_num),func_num);
        [y6,best6,bestx6]=aGPAc(fhd,D,N,M,Lx(func_num),Ux(func_num),func_num);
       

       Y1(dd,:)=y1-100.*func_num;
        Best1(dd)=best1-100.*func_num;
        Bestx1(dd,:)=bestx1;



        Y2(dd,:)=y2-100.*func_num;
        Best2(dd)=best2-100.*func_num;
        Bestx2(dd,:)=bestx2;

        
         Y3(dd,:)=y3-100.*func_num;
        Best3(dd)=best3-100.*func_num;
        Bestx3(dd,:)=bestx3;
        
        
        
         Y4(dd,:)=y4-100.*func_num;
        Best4(dd)=best4-100.*func_num;
        Bestx4(dd,:)=bestx4;
       
        
        
        
        Y5(dd,:)=y5-100.*func_num;
        Best5(dd)=best5-100.*func_num;
        Bestx5(dd,:)=bestx5;
       
  
        Y6(dd,:)=y6-100.*func_num;
        Best6(dd)=best6-100.*func_num;
        Bestx6(dd,:)=bestx6;
       
 
    end

    
    MBest(1,func_num)=mean(Best1);
    SBest(1,func_num)=std(Best1);
    [BBest(1,func_num),xh1]=min(Best1);
    BBestx1(func_num,:)=Bestx1(xh1,:);
    YY1(func_num)={Y1(xh1,:)};

    
    
    
    MBest(2,func_num)=mean(Best2);
    SBest(2,func_num)=std(Best2);    
    [BBest(2,func_num),xh2]=min(Best2);
    BBestx2(func_num,:)=Bestx2(xh2,:);
    YY2(func_num)={Y2(xh2,:)};

    
    MBest(3,func_num)=mean(Best3);
    SBest(3,func_num)=std(Best3);    
    [BBest(3,func_num),xh3]=min(Best3);
    BBestx3(func_num,:)=Bestx3(xh3,:);
    YY3(func_num)={Y3(xh3,:)};
    
     
     
    MBest(4,func_num)=mean(Best4);
    SBest(4,func_num)=std(Best4);    
    [BBest(4,func_num),xh4]=min(Best4);
    BBestx4(func_num,:)=Bestx4(xh4,:);
    YY4(func_num)={Y4(xh4,:)};
    
     
     
    MBest(5,func_num)=mean(Best5);
    SBest(5,func_num)=std(Best5);    
    [BBest(5,func_num),xh5]=min(Best5);
    BBestx5(func_num,:)=Bestx5(xh5,:);
    YY5(func_num)={Y5(xh5,:)};
    
     
    MBest(6,func_num)=mean(Best6);
    SBest(6,func_num)=std(Best6);    
    [BBest(6,func_num),xh6]=min(Best6);
    BBestx6(func_num,:)=Bestx6(xh6,:);
    YY6(func_num)={Y6(xh6,:)};
   

    

    
    
    
    zzz=linspace(0,M,11);  %no
    zzz(zzz==0) = 1;  %no
      

     figure(func_num)
     
     test=log10(YY1{1,func_num});
     plot(zzz,test(zzz),'-d','Color',[0.6 0.3 0.3]);  
     hold on
     test=log10(YY2{1,func_num});
     plot(zzz,test(zzz),'-p','Color',[1 0 0]); 
     hold on
     test=log10(YY3{1,func_num});
     plot(zzz,test(zzz),'-s','Color',[0 0.5 0.5]);  
     hold on
     test=log10(YY4{1,func_num});
     plot(zzz,test(zzz),'-^k'); 
     test=log10(YY5{1,func_num});
     plot(zzz,test(zzz),'-o','Color',[0.5 0.5 0]);   
     test=log10(YY6{1,func_num});
     plot(zzz,test(zzz),'-*b'); 
     hold on
    legend('TOGPEAe','GPA','aGPAu','aGPAn','aGPAa','aGPAc')
    xlabel( 'Number of iterations' )
    ylabel( 'Best lg(F(x)-F(x*))' )
  
end 

  
