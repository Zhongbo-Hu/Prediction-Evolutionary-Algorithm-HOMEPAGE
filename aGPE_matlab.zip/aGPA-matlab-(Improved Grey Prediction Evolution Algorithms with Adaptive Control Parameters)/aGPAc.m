function [y,best,bestx]=aGPAc(fhd,D,N,M,Lx,Ux,func_num)
global initial_flag
initial_flag=0;


 for ii=1:N
         ff(ii,1)=rand(1,1);
         hh(ii,1)=rand(1,1);
         td(ii,1)=3*ff(ii,1)+1;
         th(ii,1)=10^(-3+4*ff(ii,1));
      end


for  I=2:M
          for ii=1:N
     ff(ii,I)=4*ff(ii,I-1)*(1-ff(ii,I-1));
     hh(ii,I)=4*hh(ii,I-1)*(1-hh(ii,I-1));
     td(ii,I)=3*ff(ii,I)+1;
     th(ii,I)=10^(-3+4*hh(ii,I));
          end
end




F=0.7;%������,�������ӣ�0,1.2]
CR=0.7;%�������
lx=ones(1,D)*(Lx+abs(Lx)); 
ux=ones(1,D)*(Ux+abs(Lx));

X=repmat(lx,N,1)+(repmat(ux,N,1)-repmat(lx,N,1)).*rand(N,D);
originX(1)={X};
%Fx=benchmark_func(X-abs(Lx),func_num);
Fx=feval(fhd,X'-abs(Lx),func_num);
[y(1),~]=min(Fx);
for I=2:3
%% �������
    for i=1:N
        dx=randperm(N);   %�������1��Np֮�����ظ�������
        dx(find(dx==i))=[];
        Meta(i,:)=X(dx(1),:)+F*(X(dx(2),:)-X(dx(3),:));   %���ɱ���ʸ��Xm
    end
    for i=1:N
        for j=1:D
            if Meta(i,j)<lx(j)|Meta(i,j)>ux(j)
                 Meta(i,j)=lx(j)+(ux(j)-lx(j))*rand;
            end
        end
    end
%% �������
    for i=1:N
        for j=1:D
            r=randperm(N);
            if rand<=CR|j==r(1)
                 Xt(i,j)=Meta(i,j);
            else
                 Xt(i,j)=X(i,j);
            end
        end
    end
%% ѡ�����
    %Fxt=benchmark_func(Xt-abs(Lx),func_num); 
    Fxt=feval(fhd,Xt'-abs(Lx),func_num);
    for i=1:N
        if Fxt(i)<Fx(i)
           X(i,:)=Xt(i,:);
           Fx(i)=Fxt(i);
        end
    end
    originX(I)={X};
    [y(I),~]=min(Fx);
end    %����ѭ����ֹ
for I=4:M
    aa=randperm(N);
    bb=randperm(N);
    cc=randperm(N);
    

    for ii=1:N 
                  
          
          
        for jj=1:D
            X0=[];X1=[];Z1=[];Y=[];a=[];b=[];A=[];B=[];
            X0=[originX{1,1}(aa(ii),jj),originX{1,2}(bb(ii),jj),originX{1,3}(cc(ii),jj)];
            if abs(max(X0)-min(X0))<th(ii,I)
                     
                x1(ii,jj)=X0(3)+(0.01-((td(ii,I)-0.01)/M)*(I-M))*2*abs(max(X0)-min(X0))*(rand-0.5);
            elseif (max(X0)~=min(X0))&&(abs(X0(1)-X0(2))<th(ii,1)|abs(X0(1)-X0(3))<th(ii,1)|abs(X0(2)-X0(3))<th(ii,1))
               
                x1(ii,jj)=(4*X0(3)+X0(2)-2*X0(1))./3;
            else 
               
                a=2*(X0(2)-X0(3))/(X0(2)+X0(3));
                b=2*(X0(1)*X0(2)+X0(2)^2-X0(1)*X0(3))/(X0(2)+X0(3)); 
                %Ԥ���������  
                F=[];
                for i=1:4
                    F(i)=(X0(1)-b/a)/exp(a*(i-1))+b/a;   
                end  
                G=[];
                %G(1)=X0(1);  
                %for i=2:4 %ֻ�Ʋ��1�����ݣ����ԴӴ��޸�  
                    G(4)=F(4)-F(3); %�õ�Ԥ�����������  
                %end
                x1(ii,jj)=G(4);
            end  %�ж�X0��ֵ
            % ����Ⱥx1������Χ�����¸�ֵ
            %if func_num~=25
                 if  x1(ii,jj)<lx(jj)|x1(ii,jj)>ux(jj)
                     x1(ii,jj)=lx(jj)+(ux(jj)-lx(jj))*rand;
                 end
            %end
        end
    end
   % ѡ�����
    %Fxt=benchmark_func(x1-abs(Lx),func_num);
    Fxt=feval(fhd,x1'-abs(Lx),func_num);
    X=originX{1,3};
    for i=1:N
        if Fxt(i)<Fx(i)
           X(i,:)=x1(i,:);
           Fx(i)=Fxt(i);
        end
    end
    
    originX(1,4)={X};
    originX=originX(2:4);
    [y(I),~]=min(Fx);  %����ֵ
end    %����ѭ����ֹ
[best,zx]=min(Fx); %����ֵ
bestx=x1(zx,:)-abs(Lx); 

 
end