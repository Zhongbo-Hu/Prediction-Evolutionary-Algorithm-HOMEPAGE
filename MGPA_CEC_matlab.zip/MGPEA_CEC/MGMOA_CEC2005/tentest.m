%% ��ջ���
clc;
clear;
close all;
Dxh=30;   %����ѭ������
boundary=[-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;0,600;-32,32;-5,5;-5,5;-0.5,0.5;-100,100;-3,1;-100,100;-5,5;
    -5,5;-5,5;-5,5;-5,5;-5,5;-5,5;-5,5;-5,5;-5,5;-2,5];
Lx=boundary(:,1);
Ux=boundary(:,2);
D=10;
N=50;
M=2000;

for func_num=1:25
    disp(['��ʼ������Լ����������Ϊ��',num2str(func_num)]);
    Y1=[];Y2=[];Y3=[];Y4=[];Y5=[];
    for dd=1:Dxh
%         [y1,best1,bestx1]=NMGPEA(D,N,M,Lx(func_num),Ux(func_num),func_num);
%         [y2,best2,bestx2]=PSO(D,N,M,Lx(func_num),Ux(func_num),func_num);
%         [y3,best3,bestx3]=BSA(D,N,M,Lx(func_num),Ux(func_num),func_num);
%         [y4,best4,bestx4]=DE(D,N,M,Lx(func_num),Ux(func_num),func_num);
        try
        [y5,best5]=CMA_ES(D,N,M,Lx(func_num),Ux(func_num),func_num);
        end
%         Y1(dd,:)=y1;
%         Best1(dd)=best1;
%         Bestx1(dd,:)=bestx1;
% 
%         Y2(dd,:)=y2;
%         Best2(dd)=best2;
%         Bestx2(dd,:)=bestx2;
%         
%         Y3(dd,:)=y3;
%         Best3(dd)=best3;
%         Bestx3(dd,:)=bestx3;
%         
%         Y4(dd,:)=y4;
%         Best4(dd)=best4;
%         Bestx4(dd,:)=bestx4; 
        
        Y5(dd,:)=y5;
        Best5(dd)=best5;
    end
%     MBest(1,func_num)=mean(Best1);
%     SBest(1,func_num)=std(Best1);
%     [BBest(1,func_num),xh1]=min(Best1);
%     BBestx1(func_num,:)=Bestx1(xh1,:);
%     YY1(func_num)={Y1(xh1,:)};
%     
%     MBest(2,func_num)=mean(Best2);
%     SBest(2,func_num)=std(Best2);    
%     [BBest(2,func_num),xh2]=min(Best2);
%     BBestx2(func_num,:)=Bestx2(xh2,:);
%     YY2(func_num)={Y2(xh2,:)};
%     
%     MBest(3,func_num)=mean(Best3);
%     SBest(3,func_num)=std(Best3);
%     [BBest(3,func_num),xh3]=min(Best3);
%     BBestx3(func_num,:)=Bestx3(xh3,:);
%     YY3(func_num)={Y3(xh3,:)};
%     
%     MBest(4,func_num)=mean(Best4);
%     SBest(4,func_num)=std(Best4);
%     [BBest(4,func_num),xh4]=min(Best4);
%     BBestx4(func_num,:)=Bestx4(xh4,:);
%     YY4(func_num)={Y4(xh4,:)};
 
    MBest(5,func_num)=mean(Best5);
    SBest(5,func_num)=std(Best5);
    [BBest(5,func_num),xh5]=min(Best5);
    YY5(func_num)={Y5(xh5,:)};
    
%     figure(func_num)
%     plot(1:M,log10(YY1{1,func_num}),'r')
%     hold on
%     plot(1:M,log10(YY2{1,func_num}),'b')
%     hold on
%     plot(1:M,log10(YY3{1,func_num}),'g')
%     hold on
%     plot(1:M,log10(YY4{1,func_num}),'k')
%     hold on
%     legend('GPOA','PSO','BSA','DE')
end 
