function [y,best,bestx]=NMGPEA(D,N,M,Lx,Ux,func_num)
% clc;
% clear;
% close all;
% Lx=-100;
% Ux=100;
% D=10;
% N=50;
% M=200;
% func_num=5;

global initial_flag
initial_flag=0;

tic

lx=ones(1,D)*(Lx+abs(Lx)); 
ux=ones(1,D)*(Ux+abs(Lx));

oldX=repmat(lx,3*N,1)+(repmat(ux,3*N,1)-repmat(lx,3*N,1)).*rand(3*N,D);
oldFx=benchmark_func(oldX-abs(Lx),func_num);
[oldFx,index] = sort(oldFx,'descend');
oldX=oldX(index,:);
originX(1)={oldX(1:N,:)};
y(1)=oldFx(N);
bx(1,:)=oldX(N,:);

originX(2)={oldX(N+1:2*N,:)};
y(2)=oldFx(2*N);
bx(2,:)=oldX(2*N,:);

originX(3)={oldX(2*N+1:3*N,:)};
y(3)=min(oldFx(3*N));
bx(3,:)=oldX(3*N,:);

X=oldX(2*N+1:3*N,:);
Fx=oldFx(2*N+1:3*N);
[~,wxindex]=max(Fx);

b=zeros(N,1);
for I=4:M
    %% Ԥ��
    for ii=1:N
        if ii==wxindex%|b(ii)==1
            dx=randperm(I-1);
            k=sort(dx(1:3));
            k(4)=I;
            X0=[bx(k(1),:);bx(k(2),:);bx(k(3),:)];
        else
            k=[1,2,3];
            k(4)=4;
            X0=[originX{1,1}(ii,:);originX{1,2}(ii,:);originX{1,3}(ii,:)];
        end
        %��ԭʼ����X0 �ۼ���������X1       
        [n,m]=size(X0);
        detk=[k(1),k(2)-k(1),k(3)-k(2)];
        X1=zeros(n,m);
        X1(1,:)=X0(1,:)*detk(1);
        for i=2:n  
            X1(i,:)=X1(i-1,:)+X0(i,:)*detk(i);
        end
        %�������ݾ���L
        for i=1:n-1
            l(i,:)=(X1(i,:)+X1(i+1,:))/2;
        end
        L=[l ones(n-1,1)];
        if det(L'*L)<1E-10
            for j=1:m
               Xt(ii,j)=polyval(polyfit(k(1:3),X0(:,j)',1),k(4));
            end
        else
            %����Y����������ֵ
            Y=X0(2:n,:);
            a=inv(L'*L)*L'*Y;
            a=a';
            A=a(1:end,1:end-1);
            B=a(1:end,end);
            %����ģ�͵����ֵ��Ԥ��ֵ
            S=X1(1,1:end);
            z=expm(A*(k(4)-k(1)))*S'+inv(A)*(expm(A*(k(4)-k(1)))-eye(m))*B-(expm(A*(k(3)-k(1)))*S'+inv(A)*(expm(A*(k(3)-k(1)))-eye(m))*B);
            Xt(ii,:)=z';
        end
        for jj=1:D
            if  Xt(ii,jj)<lx(jj)|Xt(ii,jj)>ux(jj)
                Xt(ii,jj)=lx(jj)+(ux(jj)-lx(jj))*rand;
            end
%         end
        end
    end
    %% ѡ�����
    Fxt=benchmark_func(Xt-abs(Lx),func_num);
    b=zeros(N,1);
    for i=1:N
        if Fxt(i)<Fx(i)
            X(i,:)=Xt(i,:);
            Fx(i)=Fxt(i);
        else
            b(i)=1;   
        end
    end

    index = randperm(N);     %��N����Ȼ���������
    X=X(index,:);     %����һ������˳���ľ���
    Fx=Fx(index);
    b=b(index);
    [y(I),bxindex]=min(Fx);  %����ֵ
    bx(I,:)=X(bxindex,:);
    [~,wxindex]=max(Fx);
    originX(1,4)={X};
    originX=originX(2:4);
    
end    %����ѭ����ֹ 
[best,zx]=min(Fx); %����ֵ
bestx=X(zx,:); 
num2str(toc)