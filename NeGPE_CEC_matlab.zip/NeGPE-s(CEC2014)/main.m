%% Clear environment
clc;
clear;
close all;

runtimes=30;               %Number of independent cycles 
boundary=[-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100];    %The boundaries of test functions
VRmin=boundary(:,1);       %Low bound of variable
VRmax=boundary(:,2);       %Up bound of variable
Lx=boundary(:,1);
Ux=boundary(:,2);
D=10;                      %Dimensions of solution space
Pop_Number=50;             %Population size
Max_Gen=2000;              %Maximum  generations
th=0.01;                   %Difference threshold
fhd=str2func('cec14_func');
rand('state',sum(100*clock));

%%
for func_num=1:30
    disp(['��ʼ������Լ����������Ϊ��',num2str(func_num)]);
     Y5=[];
    for j=1:runtimes
         %% Search the best results using bGPEA
        [bestFitness5,bestFitness_gobal5,bestSolution_gobal5]=NeGPEs(fhd,D,Pop_Number,Max_Gen,VRmin(func_num),VRmax(func_num),func_num,th);
   
         %% Calculate the results
        
        Y5(j,:)=bestFitness5-100.*func_num;
        Best5(j)=bestFitness_gobal5-100.*func_num;
        Bestx5(j,:)=bestSolution_gobal5;

         
    end
    
    MBest(5,func_num)=mean(Best5);
    SBest(5,func_num)=std(Best5);
    [BBest(5,func_num),xh5]=min(Best5);
    BBestx5(func_num,:)=Bestx5(xh5,:);
    YY5(func_num)={Y5(xh5,:)};
    
 %% Plot figure 
%     zzz=linspace(0,Max_Gen,11);  
%     zzz(zzz==0) = 1;      
%    figure(func_num) 
%      test=log10(YY5{1,func_num});
%      plot(zzz,test(zzz),'-^b'); 
%      hold on
%     legend('NeGPEs')
%     xlabel( 'Number of iterations' )
%     ylabel( 'Mean lg(F(x)-F(x*))' )

end
