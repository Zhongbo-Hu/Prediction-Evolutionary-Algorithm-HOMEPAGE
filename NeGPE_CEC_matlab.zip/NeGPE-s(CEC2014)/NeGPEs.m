function [bestFitness,bestFitness_gobal5,bestSolution_gobal5]=NeGPEs(fhd,D,Pop_Number,Max_gen,VRmin,VRmax,func_num,th)
global initial_flag
initial_flag=0;  

%% Input:
%                                   Dimension                         Description
%               D                    1 x 1                       dimension of solution space
%             Pop_Number             1 x 1                       population size
%             Max_Gen                1 x 1                       maximum  generations
%             VRmin                  1 x D                       low bound of variable in test function
%             VRmax                  1 x D                       up bound of variable in test function
%             func_num               1 x l                       the number of test function
%�������      th                    1 x 1                       difference  threshold
%% Output:
%                             Dimension                   Description
%      bestFitness            1 x  Max_Gen                fitness values of the best individuals in each generation
%      bestFitness_gobal      1 x  1                      the fitness value of the gobal best individual
%      bestSolution_gobal     1 x  1                      the gobal best individual
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Initialize parameters
F=0.7;                    %Scaling factor or mutation factor,the value range is��0,1.2]
CR=0.9;                   %Crossover factor
%% Initialize the first generation population
Vrmin=ones(1,D)*(VRmin+abs(VRmin));                           %Initialize low bound of variable 
Vrmax=ones(1,D)*(VRmax+abs(VRmin));                           %Initialize up bound of variable
Pop=repmat(Vrmin,Pop_Number,1)+(repmat(Vrmax,Pop_Number,1)-repmat(Vrmin,Pop_Number,1)).*rand(Pop_Number,D);   %Initialize the first generation population 
originPop(1)={Pop};                                           %Store the first generation population
%% Evaluate the population
Fitness_Pop=feval(fhd,Pop'-abs(VRmin),func_num);          %Calculate the function values of the first generation population
[bestFitness(1),~]=min(Fitness_Pop);                          %Store the fitness value of the first generation population
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for I=2:3               
%% Mutation operator
%The non-equal three individuals randomly selected from the population to generate a mutation individual
    for i=1:Pop_Number
        Pop_list=randperm(Pop_Number);                                 
        Pop_list(find(Pop_list==i))=[];                             
        Mutant(i,:)=Pop(Pop_list(1),:)+F*(Pop(Pop_list(2),:)-Pop(Pop_list(3),:));     
    end                               
    for i=1:Pop_Number
        for j=1:D
            if Mutant(i,j)<Vrmin(j)||Mutant(i,j)>Vrmax(j)        %Make sure that individuals are in the setting bounds.
                 Mutant(i,j)=Vrmin(j)+(Vrmax(j)-Vrmin(j))*rand;
            end
        end
    end
%% Crossover operator
%Intersect the target individual and its corresponding mutation individual to generate trial individual of the target individual.
    for i=1:Pop_Number
        for j=1:D
            r=randperm(D);
            if rand<=CR||j==r(1)
                 trialPop(i,j)=Mutant(i,j);                     
            else
                 trialPop(i,j)=Pop(i,j);
            end
        end
    end
%% Selection operator
%Compare the value of the target individuals and trial individuals for population evaluation. Individuals with better fitness value will be selected to enter the next iteration
    Fitness_trial=feval(fhd,trialPop'-abs(VRmin),func_num);
    for i=1:Pop_Number                                         
        if Fitness_trial(i)<Fitness_Pop(i)      
           Pop(i,:)=trialPop(i,:);
           Fitness_Pop(i)=Fitness_trial(i);
        end
    end
     originPop(I)={Pop};                              %Store the second, third generation population
    [bestFitness(I),~]=min(Fitness_Pop);              %Store the fitness value of the best individual in each generation population
end    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% After a population initialization, the NeGPE-S realizes the function-optimized process by looping a reproduction operator and a selection operator for updating the population.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for I=4:Max_gen
    t=0.01-(3.99/Max_gen)*(I-Max_gen);         %The initial disturbance coefficient
    Pop_list1=randperm(Pop_Number);
    Pop_list2=randperm(Pop_Number);
    Pop_list3=randperm(Pop_Number);
%% The reproduction operator of NeGPE-S.
    for k=1:Pop_Number 
        for j=1:D
            X0=[originPop{1,1}(Pop_list1(k),j),originPop{1,2}(Pop_list2(k),j),originPop{1,3}(Pop_list3(k),j)]; 
            if abs(max(X0)-min(X0))<th                                                    
                trialPop(k,j)=X0(3)+t*2*abs(max(X0)-min(X0))*(rand-0.5);                %Random perturbation model
            elseif abs(X0(1)-X0(2))<th||abs(X0(1)-X0(3))<th||abs(X0(2)-X0(3))<th          
                trialPop(k,j)=(4*X0(3)+X0(2)-2*X0(1))/3;                                %Linear fitting model 
            else                                                                         
                a=2*(X0(2)-X0(3))/(X0(2)+X0(3));                                        %The grey developmental coefficient, Eq. (2) in the paper  
                b=2*(X0(1)*X0(2)+X0(2)^2-X0(1)*X0(3))/(X0(2)+X0(3)); %The grey control parameter, Eq. (2) in the paper              
               lambda=0.3;
               m=3+lambda;
               trialPop(k,j)=(1-exp((m-3)*a)).*(X0(1)-b/a)*exp((-a*(m-1)))/(m-3);
            end 
           %% Make sure that individuals are in the setting bounds.
            %If a newly generated individual exceeds the feasible region, the exceeding elements of the new individual are replaced by random numbers in the feasible region.
            if func_num~=25
                if  trialPop(k,j)<Vrmin(j)||trialPop(k,j)>Vrmax(j)
                    trialPop(k,j)=Vrmin(j)+(Vrmax(j)-Vrmin(j))*rand;
                end
            end
        end
    end
      % DE�������
    for i=1:Pop_Number
        for j=1:D
            r=randperm(D);
            if rand<=CR|j==r(1)
                trialPop(i,j)= trialPop(i,j);
            else
                 trialPop(i,j)=Pop(i,j);
            end
        end
    end
   

    %% The selector operator of NeGPE-S.
    Fitness_trial=feval(fhd,trialPop'-abs(VRmin),func_num); %Evaluate the trial population
    Pop=originPop{1,3};                              
    for i=1:Pop_Number
        if Fitness_trial(i)<Fitness_Pop(i)
           Pop(i,:)=trialPop(i,:);
           Fitness_Pop(i)=Fitness_trial(i);
        end
    end
     originPop(1,4)={Pop};                          %Generate the true population
     originPop=originPop(2:4);                      %Update the population chain to produce offspring
     [bestFitness(I),~]=min(Fitness_Pop);           %Store the fitness value of the best individual in each generation population
end  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Output bestFitness_gobal and bestSolution_gobal
[bestFitness_gobal5,best_index]=min(Fitness_Pop);     %The fitness value of the gobal best individual 
bestSolution_gobal5=Pop(best_index,:);                %The gobal best individual                                
 end