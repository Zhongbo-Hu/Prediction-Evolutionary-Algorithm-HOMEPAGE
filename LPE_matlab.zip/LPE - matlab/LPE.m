function [bestFitness,bestFitness_gobal,bestSolution_gobal]=LPE(fhd,D,Pop_Number,Max_gen,VRmin,VRmax,func_num)
global initial_flag
initial_flag=0;
% LPE:  Linear prediction evolution algorithm: a simplest evolutionary optimizer
% Brief description: LPE is a new optimization technique, the core of LPE is considering the population series of evolutionary algorithms as a time series, and uses the linear least square fitting model as a reproduction operator to forecast the next population.
% Dimension: D --- dimension of solution space
%% Input:
%                             Dimension                          Description
%      D                          1 x 1                       dimension of solution space
%      Pop_Number       1 x 1                       population size
%      Max_Gen              1 x 1                       maximum  generations
%      VRmin                  1 x D                       low bound of variable in test function
%      VRmax                  1 x D                       up bound of variable in test function
%      func_num             1 x 1                        the number of test function
%% Output:
%                                        Dimension                       Description
%      bestFitness              1 x  Max_Gen             fitness values of the best individuals in each generation
%      bestFitness_gobal       1 x  1                      the fitness value of the gobal best individual
%      bestSolution_gobal     1 x  1                      the gobal best individual
%%  Reference and Contact
% Reference: [1]Cong Gao, Zhongbo Hu, and Wangyu Tong. Linear prediction evolution algorithm: a simplest evolutionary optimizer. Memetic Computing, 2021. https://doi.org/10.1007/s12293-021-00340-x
%                   [2]Zhongbo Hu, Xinlin Xu, Qinghua Su, Huimin Zhu, Jinhai Guo. Grey prediction evolution algorithm for global optimization, Applied Mathematical Modelling, 2020, 79, 145�C160.https://doi.org/10.1016/j.apm.2019.10.026
%                   [3]Zhongbo Hu, Cong Gao, and Qinghua Su. A novel evolutionary algorithm based on even difference grey model. Expert Systems with Applications, 2021, 114898. https://doi.org/10.1016/j.eswa.2021.114898
%                   [4]Xinlin Xu, Zhongbo Hu, Qinghua Su, Yuanxiang Li, Juanhua Dai. Multivariable grey prediction evolution algorithm: A new metaheuristic, Applied Soft Computing, 2020, 89, 106086. https://doi.org/10.1016/j.asoc.2020.106086
%                   [5]Canyun Dai, Zhongbo Hu, Zheng Li, Zenggang Xiong, Qinghua Su. An improved grey prediction evolution algorithm based on Topological Opposition-based learning. IEEE Access, vol. 8, pp. 30745-30762, 2020.https://doi.org/10.1109/ACCESS.2020.2973197
%                   [6]Zhongbo Hu, Zheng Li, Canyun Dai, Xinlin Xu, Zenggang Xiong, Qinghua Su. Multiobjective grey prediction evolution algorithm for environmental/economic dispatch problem. IEEE Access, vol. 8, pp. 84162-84176, 2020. https://doi.org/10.1109/ACCESS.2020.2992116
%                   [7]Cong Gao, Zhongbo Hu, Zenggang Xiong, Qinghua Su. Grey Prediction Evolution Algorithm Based on Accelerated Even Grey Model. IEEE Access, vol. 8, pp. 107941-107957, 2020.  https://doi.org/10.1109/ACCESS.2020.3001194
%                   [8]Ting Zhou, Zhongbo Hu, Quan Zhou, and Shixiong Yuan. A novel grey prediction evolution algorithm for multimodal multiobjectiveoptimization. Engineering Applications of Artificial Intelligence, 2021,100:104173. https://doi.org/10.1016/j.engappai.2021.104173
% Contact: For any questions, please feel free to send email to huzbdd@126.com.
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% The initialization operator of LPE. 
%LPE needs to initialize three generation populations, there is an alternative to implement initialization by means of other evolutionary algorithms (such as DE, PSO��).
%In this program, the initialization of LPE is completed by means of DE, and the initialization process includes two parts:
%The first part is to initialize the first generation with random uniform distribution;
%The second part is to generate the second and third generation population using DE.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Initialize the first generation population
Vrmin=ones(1,D)*(VRmin+abs(VRmin));                           %Initialize low bound of variable 
Vrmax=ones(1,D)*(VRmax+abs(VRmin));                           %Initialize up bound of variable
Pop=repmat(Vrmin,Pop_Number,1)+(repmat(Vrmax,Pop_Number,1)-repmat(Vrmin,Pop_Number,1)).*rand(Pop_Number,D);   %Initialize the first generation population 
originPop(1)={Pop};                                           %Store the first generation population
%% Evaluate the population
Fitness_Pop=feval(fhd,Pop'-abs(VRmin),func_num);          %Calculate the function values of the first generation population 
[bestFitness(1),~]=min(Fitness_Pop);                          %Store the fitness value of the first generation population  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for I=2:3      
%% Initialize parameters of DE
F=0.7;                  %Scaling factor or mutation factor,the value range is��0,1.2]
CR=0.7;                   %Crossover factor
%% Mutation operator of DE
%Three individuals are randomly selected from the population for generating a mutation individual
    for i=1:Pop_Number
        Pop_list=randperm(Pop_Number);                                 
        Pop_list(find(Pop_list==i))=[];                             
        Mutant(i,:)=Pop(Pop_list(1),:)+F*(Pop(Pop_list(2),:)-Pop(Pop_list(3),:));     
    end                               
    for i=1:Pop_Number
        for j=1:D
            if Mutant(i,j)<Vrmin(j)||Mutant(i,j)>Vrmax(j)        %Make sure that individuals are in the setting bounds.
                 Mutant(i,j)=Vrmin(j)+(Vrmax(j)-Vrmin(j))*rand;
            end
        end
    end
%% Crossover operator of DE
%Intersect the target individual and its corresponding mutation individual to generate trial individual of the target individual.
    for i=1:Pop_Number
        for j=1:D
            r=randperm(D);
            if rand<=CR||j==r(1)
                 trialPop(i,j)=Mutant(i,j);                     
            else
                 trialPop(i,j)=Pop(i,j);
            end
        end
    end
%% Selection operator of DE
%Compare the value of the target individuals and trial individuals for population evaluation. Individuals with better fitness value will be selected to enter the next iteration
    Fitness_trial=feval(fhd,trialPop'-abs(VRmin),func_num);   %Evaluate the trial population
    for i=1:Pop_Number                                         
        if Fitness_trial(i)<Fitness_Pop(i)      
           Pop(i,:)=trialPop(i,:);
           Fitness_Pop(i)=Fitness_trial(i);
        end
    end
     originPop(I)={Pop};                              %Store the second, third generation population
    [bestFitness(I),~]=min(Fitness_Pop);              %Store the fitness value of the best individual in each generation population
end    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% After a population initialization, LPE realizes the function-optimized process by looping a reproduction operator and a selection operator for updating the population.
%% The reproduction operator of LPE.
%Firstly, LPE randomly selects three individuals from three consecutive populations, respectively, and then fits a line on each dimension of the three individuals by using the linear least square fitting model. 
%Finally, LPE regards the line expression as its reproduction operator to generate the offspring individuals.
%% The selector operator of LPE.
%A greedy selection operator is employed to maintain the most promising trial individuals in the next generation.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for I=4:Max_gen
    Pop_list1=randperm(Pop_Number);
    Pop_list2=randperm(Pop_Number);
    Pop_list3=randperm(Pop_Number);
%% The reproduction operator of LPE.
    for k=1:Pop_Number 
        for j=1:D
            X0=[originPop{1,1}(Pop_list1(k),j),originPop{1,2}(Pop_list2(k),j),originPop{1,3}(Pop_list3(k),j)];        
                trialPop(k,j)=(4*X0(3)+X0(2)-2*X0(1))/3;                                %Linear least square fitting model                
                if  trialPop(k,j)<Vrmin(j)||trialPop(k,j)>Vrmax(j)               % Make sure that individuals are in the setting bounds.
                    trialPop(k,j)=Vrmin(j)+(Vrmax(j)-Vrmin(j))*rand;
                end
        end
    end  
    % NOTE.  When dealing with high-dimensional (complex) problems, some operators (such as a crossover operator) for improving the exploration capability of the algorithm may help LPE  to achieve better performance.
%% The selector operator of LPE.
    Fitness_trial=feval(fhd,trialPop'-abs(VRmin),func_num);    %Evaluate the trial population
    Pop=originPop{1,3};                              
    for i=1:Pop_Number
        if Fitness_trial(i)<Fitness_Pop(i)
           Pop(i,:)=trialPop(i,:);
           Fitness_Pop(i)=Fitness_trial(i);
        end
    end
     originPop(1,4)={Pop};                          %Generate the true population
     originPop=originPop(2:4);                      %Update the population chain to produce offspring
     [bestFitness(I),~]=min(Fitness_Pop);           %Store the fitness value of the best individual in each generation population
end  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Output bestFitness_gobal and bestSolution_gobal
[bestFitness_gobal,best_index]=min(Fitness_Pop);     %The fitness value of the gobal best individual 
bestSolution_gobal=Pop(best_index,:);                %The gobal best individual                                
end