%% Clear environment
clc;
clear;
close all;

runtimes=30;             %Number of independent cycles
boundary=[-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;-100,100];        %The boundaries of test functions
VRmin=boundary(:,1);       %Low bound of variable
VRmax=boundary(:,2);       %Up bound of variable
D=10;                                 %Dimensions of solution space
Pop_Number=50;              %Population size
Max_Gen=2000;              %Maximum  generations
fhd=str2func('cec14_func');      %Test functions
rand('state',sum(100*clock));     

for func_num=1:30
    disp(['The number of the current test function: ',num2str(func_num)]);
    Y1=[];Y2=[];Y3=[];Y4=[];Y5=[];
    for j=1:runtimes
        %% Search the best results using LPE
        [bestFitness1,bestFitness_gobal1,bestSolution_gobal1]=LPE(fhd,D,Pop_Number,Max_Gen,VRmin(func_num),VRmax(func_num),func_num);
        %% Search the best results using GPE
        [bestFitness2,bestFitness_gobal2,bestSolution_gobal2]=GPE(fhd,D,Pop_Number,Max_Gen,VRmin(func_num),VRmax(func_num),func_num);
        %% Search the best results using PSO
        [bestFitness3,bestFitness_gobal3,bestSolution_gobal3]=PSO(fhd,D,Pop_Number,Max_Gen,VRmin(func_num),VRmax(func_num),func_num);
        %% Search the best results using BSA
        [bestFitness4,bestFitness_gobal4,bestSolution_gobal4]=BSA(fhd,D,Pop_Number,Max_Gen,VRmin(func_num),VRmax(func_num),func_num);
        %% Search the best results using DE
        [bestFitness5,bestFitness_gobal5,bestSolution_gobal5]=DE(fhd,D,Pop_Number,Max_Gen,VRmin(func_num),VRmax(func_num),func_num);    
        
        %% Calculate the results
        Y1(j,:)=bestFitness1-100.*func_num;
        Best1(j)=bestFitness_gobal1-100.*func_num;
        Bestx1(j,:)=bestSolution_gobal1;

        Y2(j,:)=bestFitness2-100.*func_num;
        Best2(j)=bestFitness_gobal2-100.*func_num;
        Bestx2(j,:)=bestSolution_gobal2;
        
        Y3(j,:)=bestFitness3-100.*func_num;
        Best3(j)=bestFitness_gobal3-100.*func_num;
        Bestx3(j,:)=bestSolution_gobal3;

        Y4(j,:)=bestFitness4-100.*func_num;
        Best4(j)=bestFitness_gobal4-100.*func_num;
        Bestx4(j,:)=bestSolution_gobal4;
        
        Y5(j,:)=bestFitness5-100.*func_num;
        Best5(j)=bestFitness_gobal5-100.*func_num;
        Bestx5(j,:)=bestSolution_gobal5;

    
    end
    
    MBest(1,func_num)=mean(Best1);
    SBest(1,func_num)=std(Best1);
    [BBest(1,func_num),xh1]=min(Best1);
    BBestx1(func_num,:)=Bestx1(xh1,:);
    YY1(func_num)={Y1(xh1,:)};
    
    MBest(2,func_num)=mean(Best2);
    SBest(2,func_num)=std(Best2);    
    [BBest(2,func_num),xh2]=min(Best2);
    BBestx2(func_num,:)=Bestx2(xh2,:);
    YY2(func_num)={Y2(xh2,:)};
    
   MBest(3,func_num)=mean(Best3);
    SBest(3,func_num)=std(Best3);
    [BBest(3,func_num),xh3]=min(Best3);
    BBestx3(func_num,:)=Bestx3(xh3,:);
    YY3(func_num)={Y3(xh3,:)};
    
    MBest(4,func_num)=mean(Best4);
    SBest(4,func_num)=std(Best4);
    [BBest(4,func_num),xh4]=min(Best4);
    BBestx4(func_num,:)=Bestx4(xh4,:);
    YY4(func_num)={Y4(xh4,:)};
    
    MBest(5,func_num)=mean(Best5);
    SBest(5,func_num)=std(Best5);
    [BBest(5,func_num),xh5]=min(Best5);
    BBestx5(func_num,:)=Bestx5(xh5,:);
    YY5(func_num)={Y5(xh5,:)};
    
    %% Plot figure 
    zzz=linspace(0,Max_Gen,11);  
    zzz(zzz==0) = 1;    
    figure(func_num)
     test=log10(YY1{1,func_num});
     plot(zzz,test(zzz),'-p','Color',[1 0 0]);  
     hold on
     test=log10(YY2{1,func_num});
     plot(zzz,test(zzz),'-*b');  
     hold on
     test=log10(YY3{1,func_num});
     plot(zzz,test(zzz),'-^k'); 
     hold on
     test=log10(YY4{1,func_num});
     plot(zzz,test(zzz),'-o','Color',[0.5 0.5 0]);   
     hold on
     test=log10(YY5{1,func_num});
     plot(zzz,test(zzz),'-s','Color',[0 0.5 0.5]);   
     hold on
    legend('LPE','GPE','PSO','BSA','DE')
    xlabel( 'Number of iterations' )
    ylabel( 'Mean lg(F(x)-F(x*))' )
end 


