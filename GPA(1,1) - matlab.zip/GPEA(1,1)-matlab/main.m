%% Clear environment
clc;
clear;
close all;

runtimes=30;               %Number of independent cycles
boundary=[-100,100;-100,100;-100,100;-100,100;-100,100;-100,100;0,600;-32,32;-5,5;-5,5;-0.5,0.5;-100,100;-3,1;-100,100;-5,5;
    -5,5;-5,5;-5,5;-5,5;-5,5;-5,5;-5,5;-5,5;-5,5;-2,5];    %The boundaries of test functions
VRmin=boundary(:,1);       %Low bound of variable
VRmax=boundary(:,2);       %Up bound of variable
D=10;                      %Dimensions of solution space
Pop_Number=50;             %Population size
Max_Gen=2000;              %Maximum  generations
th=0.01;                   %Difference threshold

for func_num=1:25
    disp(['��ʼ������Լ����������Ϊ��',num2str(func_num)]);
     Y1=[];Y2=[];Y3=[];Y4=[];
    for j=1:runtimes
        %% Search the best results using GPEA
        [bestFitness1,bestFitness_gobal1,bestSolution_gobal1]=GPEA(D,Pop_Number,Max_Gen,VRmin(func_num),VRmax(func_num),func_num,th);
        %% Search the best results using PSO
        [bestFitness2,bestFitness_gobal2,bestSolution_gobal2]=PSO(D,Pop_Number,Max_Gen,VRmin(func_num),VRmax(func_num),func_num);
        %% Search the best results using DE
        [bestFitness3,bestFitness_gobal3,bestSolution_gobal3]=DE(D,Pop_Number,Max_Gen,VRmin(func_num),VRmax(func_num),func_num);
        %% Calculate the results
        Y1(j,:)=bestFitness1;
        Best1(j)=bestFitness_gobal1;
        Bestx1(j,:)=bestSolution_gobal1;

        Y2(j,:)=bestFitness2;
        Best2(j)=bestFitness_gobal2;
        Bestx2(j,:)=bestSolution_gobal2;
        
        Y3(j,:)=bestFitness3;
        Best3(j)=bestFitness_gobal3;
        Bestx3(j,:)=bestSolution_gobal3;
         
    end
    MBest(1,func_num)=mean(Best1);
    SBest(1,func_num)=std(Best1);
    [BBest(1,func_num),xh1]=min(Best1);
    BBestx1(func_num,:)=Bestx1(xh1,:);
    YY1(func_num)={Y1(xh1,:)};
    
    MBest(2,func_num)=mean(Best2);
    SBest(2,func_num)=std(Best2);    
    [BBest(2,func_num),xh2]=min(Best2);
    BBestx2(func_num,:)=Bestx2(xh2,:);
    YY2(func_num)={Y2(xh2,:)};
    
    MBest(3,func_num)=mean(Best3);
    SBest(3,func_num)=std(Best3);
    [BBest(3,func_num),xh3]=min(Best3);
    BBestx3(func_num,:)=Bestx3(xh3,:);
    YY3(func_num)={Y3(xh3,:)};
    
 %% Plot figure 
    figure(func_num)
    plot(1:Max_Gen,log10(YY1{1,func_num}),'r')
    hold on
    plot(1:Max_Gen,log10(YY2{1,func_num}),'b')
    hold on
    plot(1:Max_Gen,log10(YY3{1,func_num}),'k')
    hold on
    legend('GPEA','PSO','DE')
end 

